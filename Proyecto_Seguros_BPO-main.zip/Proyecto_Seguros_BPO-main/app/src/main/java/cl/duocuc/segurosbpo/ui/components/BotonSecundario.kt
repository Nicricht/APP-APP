package cl.duocuc.segurosbpo.ui.components

import androidx.compose.foundation.layout.padding
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Modifier
import androidx.compose.ui.tooling.preview.Preview
import androidx.compose.ui.unit.dp
import cl.duocuc.segurosbpo.ui.style.estiloAltoBoton
import cl.duocuc.segurosbpo.ui.style.EstilosBotones
import cl.duocuc.segurosbpo.ui.theme.SegurosBpoTheme

// =====================================================================
//  BotonSecundario.kt  —  Acción de menor importancia (Limpiar, Cancelar).
//  Parte de OutlinedButton (solo borde) y aplica NUESTROS estilos.
// =====================================================================

@Composable
fun BotonSecundario(
    texto: String,
    onClick: () -> Unit,
    modifier: Modifier = Modifier
) {
    OutlinedButton(
        onClick = onClick,
        modifier = modifier.estiloAltoBoton(),
        shape = EstilosBotones.forma,
        colors = EstilosBotones.coloresSecundarios(),
        border = EstilosBotones.bordeSecundario(),       // border: 2px solid
        contentPadding = EstilosBotones.relleno
    ) {
        Text(text = texto)
    }
}

@Preview(showBackground = true)
@Composable
private fun BotonSecundarioPreview() {
    SegurosBpoTheme {
        BotonSecundario(texto = "Limpiar", onClick = {}, modifier = Modifier.padding(16.dp))
    }
}
